"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Sidebar, SIDEBAR_WIDTH } from "./Sidebar";
import { NotificationsPopover } from "@/components/notifications/NotificationsPopover";

const LAYOUT_TRANSITION = { type: "spring" as const, stiffness: 320, damping: 34 };

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const marginLeft = collapsed ? SIDEBAR_WIDTH.collapsed : SIDEBAR_WIDTH.expanded;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Sidebar
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((v) => !v)}
      />

      <motion.main
        animate={{ marginLeft }}
        transition={LAYOUT_TRANSITION}
        className="min-h-screen"
      >
        <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center justify-end border-b border-slate-200/60 bg-slate-50/95 px-6 backdrop-blur-sm">
          <NotificationsPopover />
        </header>

        <div className="p-6">
          <div className="mx-auto w-full max-w-6xl">{children}</div>
        </div>
      </motion.main>
    </div>
  );
}

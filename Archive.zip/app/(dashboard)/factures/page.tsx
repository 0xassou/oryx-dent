const FACTURES = [
  {
    id: "FAC-001",
    patient: "Marie Dupont",
    date: "14 mars 2026",
    montant: "85 €",
    statut: "payée",
  },
  {
    id: "FAC-002",
    patient: "Jean Martin",
    date: "13 mars 2026",
    montant: "210 €",
    statut: "en-attente",
  },
  {
    id: "FAC-003",
    patient: "Sophie Bernard",
    date: "12 mars 2026",
    montant: "650 €",
    statut: "payée",
  },
  {
    id: "FAC-004",
    patient: "Pierre Leroy",
    date: "11 mars 2026",
    montant: "85 €",
    statut: "en-attente",
  },
  {
    id: "FAC-005",
    patient: "Claire Moreau",
    date: "10 mars 2026",
    montant: "320 €",
    statut: "payée",
  },
  {
    id: "FAC-006",
    patient: "Lucas Garnier",
    date: "8 mars 2026",
    montant: "50 €",
    statut: "payée",
  },
] as const;

export default function FacturesPage() {
  const total = FACTURES.reduce((acc, f) => {
    const val = parseInt(f.montant.replace(" €", ""), 10);
    return acc + (f.statut === "payée" ? val : 0);
  }, 0);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-slate-800">Factures</h1>

      <div className="rounded-xl bg-gradient-to-r from-sky-500 to-teal-500 px-6 py-5 text-white shadow-lg">
        <p className="text-sm text-sky-100">Total encaissé ce mois</p>
        <p className="mt-1 text-3xl font-bold">{total} €</p>
      </div>

      <div className="rounded-xl bg-white p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[500px]">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Référence
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Patient
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Date
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Montant
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Statut
                </th>
              </tr>
            </thead>
            <tbody>
              {FACTURES.map((facture) => (
                <tr
                  key={facture.id}
                  className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50"
                >
                  <td className="py-4 text-sm font-mono text-slate-500">
                    {facture.id}
                  </td>
                  <td className="py-4 text-sm font-medium text-slate-800">
                    {facture.patient}
                  </td>
                  <td className="py-4 text-sm text-slate-600">{facture.date}</td>
                  <td className="py-4 text-sm font-semibold text-slate-800">
                    {facture.montant}
                  </td>
                  <td className="py-4">
                    <span
                      className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        facture.statut === "payée"
                          ? "bg-teal-100 text-teal-700"
                          : "bg-amber-100 text-amber-700"
                      }`}
                    >
                      {facture.statut === "payée" ? "Payée" : "En attente"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

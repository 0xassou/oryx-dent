"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ChevronLeft, Download, Eye, FileText, Mail, Phone, Plus, UploadCloud, X } from "lucide-react";
import { PatientFinanceCard } from "@/components/finance/PatientFinanceCard";
import {
  PrescriptionModal,
  type PrescriptionItem,
} from "@/components/patients/PrescriptionModal";
import {
  DentalChart as DentalChartComponent,
  type ToothId,
  type ToothStatus,
} from "@/components/dentition/DentalChart";

// ── Actes par catégorie clinique ─────────────────────────────────────────────
const ACTES_PAR_CATEGORIE: Record<string, string[]> = {
  Saine: [],
  Soins: [
    "Composite 1 face",
    "Composite 2 faces",
    "Composite 3 faces",
    "Soin Verre Ionomère (CVI)",
    "Détartrage & polissage",
    "Scellement de sillon",
    "Désensibilisation cervicale",
    "Traitement canalaire (Incisive/Canine)",
    "Traitement canalaire (Prémolaire)",
    "Traitement canalaire (Molaire)",
    "Reprise endodontique",
    "Pulpotomie",
    "Coiffage pulpaire direct",
    "Apexification",
  ],
  Endodontie: [
    "Traitement canalaire (Incisive/Canine)",
    "Traitement canalaire (Prémolaire)",
    "Traitement canalaire (Molaire)",
    "Reprise endodontique",
    "Pulpotomie",
    "Coiffage pulpaire direct",
    "Apexification",
  ],
  Orthopédie: [
    "Couronne Céramique-Zircone",
    "Couronne Métal-Céramique",
    "Couronne Provisoire",
    "Inlay/Onlay Céramique",
    "Facette en céramique",
    "Bridge 3 éléments",
    "Gouttière occlusale",
  ],
  Chirurgie: [
    "Extraction simple",
    "Avulsion dent de sagesse (simple)",
    "Avulsion dent de sagesse (chirurgicale)",
    "Alvéoloplastie",
    "Pose d'implant",
    "Greffe osseuse",
    "Frénectomie",
  ],
  Absente: [],
};

// Mapping catégorie -> statut de la dent dans le schéma
const CATEGORY_TO_STATUS: Record<string, ToothStatus> = {
  Saine: "healthy",
  Soins: "carie",
  Endodontie: "carie",
  Orthopédie: "couronne",
  Chirurgie: "chirurgie",
  Absente: "absente",
};

// Toutes les IDs de dents pour l'état initial
const ALL_TOOTH_IDS: ToothId[] = [
  18, 17, 16, 15, 14, 13, 12, 11,
  21, 22, 23, 24, 25, 26, 27, 28,
  48, 47, 46, 45, 44, 43, 42, 41,
  31, 32, 33, 34, 35, 36, 37, 38,
];

type TabId = "historique" | "radios" | "finances";

interface PatientProfile {
  id: string;
  nom: string;
  age: number;
  profession: string;
  telephone: string;
  email: string;
  alerts: string[];
}

const MOCK_PROFILES: Record<string, PatientProfile> = {
  "1": {
    id: "1",
    nom: "Karim Haddad",
    age: 44,
    profession: "Chirurgien-dentiste",
    telephone: "06 12 34 56 78",
    email: "karim.haddad@email.fr",
    alerts: ["Allergie Pénicilline", "Hypertendu"],
  },
  "2": {
    id: "2",
    nom: "Sarah Benali",
    age: 31,
    profession: "Assistante médicale",
    telephone: "06 98 76 54 32",
    email: "sarah.benali@email.fr",
    alerts: ["Allergie Latex"],
  },
  "3": {
    id: "3",
    nom: "Marie Dupont",
    age: 42,
    profession: "Cadre administratif",
    telephone: "07 11 22 33 44",
    email: "marie.dupont@email.fr",
    alerts: ["Diabète de type 2"],
  },
};

function getInitials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const first = parts[0]?.[0] ?? "";
  const second = parts.length > 1 ? parts[parts.length - 1]?.[0] : "";
  return (first + second).toUpperCase();
}

export default function PatientDetailPage() {
  const params = useParams();
  const id = (params?.id as string) ?? "";

  const profile: PatientProfile =
    MOCK_PROFILES[id] ?? {
      id,
      nom: `Patient #${id}`,
      age: 0,
      profession: "—",
      telephone: "—",
      email: "—",
      alerts: [],
    };

  const [tab, setTab] = useState<TabId>("historique");
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);

  // État contrôlé du schéma dentaire
  const [dentsStatus, setDentsStatus] = useState<Record<ToothId, ToothStatus>>(
    () =>
      Object.fromEntries(
        ALL_TOOTH_IDS.map((id) => [id, "healthy" as ToothStatus])
      ) as Record<ToothId, ToothStatus>
  );

  // Fiche Clinique Multi-Actes (cockpit)
  const [allTreatments, setAllTreatments] = useState<
    Array<{
      tooth: number;
      category: string;
      acte: string;
      date: string;
      notes?: string;
      lt?: string;
    }>
  >([]);

  // Mock de prévisualisation — à retirer en production
  useEffect(() => {
    setAllTreatments([
      {
        tooth: 21,
        category: "Chirurgie",
        acte: "Extraction simple",
        date: "Aujourd'hui",
        notes:
          "Extraction sous AL (Articaïne 4%). Détorsion/luxation contrôlées. Alvéole nettoyée, saignement maîtrisé. Pansement mis en place + consignes post-opératoires remises.",
        lt: "",
      },
      {
        tooth: 16,
        category: "Soins",
        acte: "Composite 2 faces",
        date: "17 Mars 2026",
        notes:
          "Mise en place de digue. Préparation et conditionnement de la cavité. Insertion composite, finition/polissage. Contrôle de l'occlusion.",
        lt: "",
      },
      {
        tooth: 15,
        category: "Soins",
        acte: "Traitement canalaire (Prémolaire)",
        date: "15 Mars 2026",
        notes:
          "Accès canalaire, mise en forme, irrigation et obturation provisoire. Contrôle radiographique de la longueur de travail.",
        lt: "18.5",
      },
      {
        tooth: 35,
        category: "Orthopédie",
        acte: "Gouttière occlusale",
        date: "10 Mars 2026",
        notes:
          "Empreinte et conception. Ajustement initial sur articulateur. Conseils d'utilisation et rappel pour re-évaluation à J+10.",
        lt: "",
      },
    ]);
  }, []);

  // Slide-over saisie clinique
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [toothCategory, setToothCategory] = useState("Soins");
  const [toothActe, setToothActe] = useState("");
  const [toothLT, setToothLT] = useState("");
  const [toothNotes, setToothNotes] = useState("");

  const initials = getInitials(profile.nom);

  const timeline = [
    {
      date: "12 Mars 2026",
      titre: "Détartrage et polissage",
      note: "Contrôle parodontite léger + conseils d’hygiène bucco-dentaire.",
    },
    {
      date: "05 Février 2026",
      titre: "Urgence pulpite dent 46",
      note: "Analgésie, traitement initial et planification du suivi.",
    },
    {
      date: "18 Janvier 2026",
      titre: "Contrôle & radiographie",
      note: "Bilan périapical et revue du plan de soins.",
    },
  ];

  const existingTreatmentForSelectedTooth =
    selectedTooth !== null
      ? allTreatments.find((t) => t.tooth === selectedTooth) ?? null
      : null;

  return (
    <div className="bg-slate-50 min-h-screen p-6">
      <div className="flex flex-col gap-6">
        {/* En-tête */}
        <div className="flex items-center gap-3">
          <Link
            href="/patients"
            className="inline-flex items-center gap-2 text-xs font-medium text-slate-500 hover:text-[color:var(--ds-primary)]"
          >
            <ChevronLeft className="h-4 w-4" />
            Retour aux patients
          </Link>
        </div>

        {/* Section Haut : Profil + Fiche Clinique (gauche) / Schéma Dentaire (droite) */}
        <div className="grid lg:grid-cols-12 gap-6 items-stretch">
          {/* Colonne patient (gauche) */}
          <aside className="lg:col-span-4 flex flex-col gap-4 h-full">
            {/* Profil Patient */}
            <section className="rounded-3xl bg-white p-4 shadow-sm h-full">
              <div className="flex flex-col gap-3 h-full">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-500 to-teal-500 text-white shadow-[0_10px_30px_rgba(14,165,233,0.25)]">
                    <span className="text-sm font-semibold">{initials}</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="truncate text-lg font-semibold text-[color:var(--ds-text)]">
                      {profile.nom}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {profile.age ? `${profile.age} ans` : "Âge inconnu"} ·{" "}
                      {profile.profession}
                    </p>
                  </div>
                </div>

                {/* Contact */}
                <div className="space-y-2">
                  <div className="w-full rounded-2xl border border-slate-100 bg-white px-3 py-2">
                    <p className="text-xs font-medium text-slate-500">
                      Numéro de téléphone :
                    </p>
                    <div className="mt-1 flex items-center gap-2 text-sm text-slate-700">
                      <Phone className="h-4 w-4 text-slate-400" aria-hidden />
                      <span className="truncate">{profile.telephone}</span>
                    </div>
                  </div>

                  <div className="w-full rounded-2xl border border-slate-100 bg-white px-3 py-2">
                    <p className="text-xs font-medium text-slate-500">
                      Adresse email :
                    </p>
                    <div className="mt-1 flex items-center gap-2 text-sm text-slate-700">
                      <Mail className="h-4 w-4 text-slate-400" aria-hidden />
                      <span className="truncate">{profile.email}</span>
                    </div>
                  </div>
                </div>

                {/* Alertes Médicales (remontées sous l'email) */}
                <div className="mt-2 w-full">
                  <div className="rounded-2xl border border-red-100 bg-red-50 p-3 w-full">
                    <p className="text-xs font-semibold uppercase tracking-wider text-red-600">
                      Alertes Médicales
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {profile.alerts.length === 0 ? (
                        <span className="text-xs text-red-600/70">Aucune</span>
                      ) : (
                        profile.alerts.map((a) => (
                          <span
                            key={a}
                            className="inline-flex rounded-lg bg-red-100 px-2.5 py-1 text-[11px] font-semibold text-red-700"
                          >
                            {a}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Fiche Clinique Multi-Actes (La Liste) */}
            {allTreatments.length > 0 && (
              <section className="w-full bg-white rounded-3xl p-6 shadow-sm">
                <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                  Cockpit Clinique / Actes Enregistrés
                </h2>

                <div className="mt-4 space-y-4 pr-2 overflow-y-auto max-h-80">
                  {allTreatments.map((acte, idx) => {
                    const isSoins =
                      acte.category === "Soins" ||
                      acte.category === "Endodontie";
                    const isOrthopedie = acte.category === "Orthopédie";
                    const isChirurgie = acte.category === "Chirurgie";

                    const bgClass = isSoins
                      ? "bg-red-50"
                      : isOrthopedie
                        ? "bg-blue-50"
                        : isChirurgie
                          ? "bg-yellow-50"
                          : acte.category === "Absente"
                            ? "bg-slate-100"
                            : "bg-gray-50";

                    const badgeTextClass = isOrthopedie
                      ? "text-blue-700"
                      : isChirurgie
                        ? "text-yellow-800"
                        : isSoins
                          ? "text-red-700"
                          : acte.category === "Absente"
                            ? "text-slate-800"
                            : "text-slate-800";

                    const badgeBgClass = isOrthopedie
                      ? "bg-blue-50"
                      : isChirurgie
                        ? "bg-yellow-50"
                        : isSoins
                          ? "bg-red-50"
                          : acte.category === "Absente"
                            ? "bg-slate-100"
                            : "bg-gray-50";

                    return (
                      <div
                        key={`${acte.tooth}-${acte.acte}-${idx}`}
                        className={`flex items-center gap-3 p-3 ${bgClass} rounded-xl shadow-sm`}
                      >
                        <div
                          className={[
                            "size-10 shrink-0 rounded-full flex flex-col items-center justify-center",
                            badgeBgClass,
                            badgeTextClass,
                          ].join(" ")}
                        >
                          <svg
                            viewBox="0 0 24 24"
                            className="h-4 w-4"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <path d="M7 3c-2.2 0-4 2.2-3.3 4.5l1.1 3.2c.4 1.3.6 2.5.7 3.9.2 2.6 1.1 6.4 4.5 6.4 1.3 0 2.1-.6 2.6-1.2.5.6 1.3 1.2 2.6 1.2 3.4 0 4.3-3.8 4.5-6.4.1-1.4.3-2.6.7-3.9l1.1-3.2C23 5.2 21.2 3 19 3H7z" />
                            <path d="M9 12c.5 1 1.5 1.8 3 1.8S14.5 13 15 12" />
                          </svg>
                          <span className="mt-0.5 text-sm font-bold leading-none">
                            {acte.tooth}
                          </span>
                        </div>

                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-slate-700 truncate">
                            {acte.acte}
                          </p>
                          <p className="text-xs font-medium text-slate-500">
                            {acte.date}
                          </p>
                          <p className="text-xs text-slate-400 truncate">
                            {acte.notes
                              ? acte.notes.length > 50
                                ? acte.notes.slice(0, 50) + "…"
                                : acte.notes
                              : "—"}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </aside>

          {/* Schéma Dentaire (droite) */}
          <section className="lg:col-span-8 w-full h-full overflow-hidden rounded-3xl bg-white p-6 shadow-sm">
            <DentalChartComponent
              value={dentsStatus}
              onValueChange={setDentsStatus}
              onChange={(state) => {
                console.log("DentalChart change", { patientId: id, state });
              }}
              onToothClick={(tooth) => {
                const existingTreatment = allTreatments.find((t) => t.tooth === tooth);
                setSelectedTooth(tooth);

                if (existingTreatment) {
                  const normalizedCategory =
                    existingTreatment.category === "Endodontie"
                      ? "Soins"
                      : existingTreatment.category;
                  setToothCategory(normalizedCategory);
                  setToothActe(existingTreatment.acte);
                  setToothLT(existingTreatment.lt || "");
                  setToothNotes(existingTreatment.notes || "");
                } else {
                  setToothCategory("");
                  setToothActe("");
                  setToothLT("");
                  setToothNotes("");
                }
              }}
            />
          </section>
        </div>

        {/* Section Bas : onglets + contenu pleine largeur */}
        <section className="w-full bg-white rounded-3xl p-6 shadow-sm">
          {/* Menu des onglets */}
          <div className="w-full overflow-x-auto">
            <div className="flex flex-row flex-nowrap overflow-x-auto gap-2 w-full scrollbar-hide whitespace-nowrap [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <button
                type="button"
                onClick={() => setTab("historique")}
                className={[
                  "whitespace-nowrap flex-shrink-0 rounded-2xl px-3 py-2 text-sm font-medium transition-all",
                  tab === "historique"
                    ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-700",
                ].join(" ")}
              >
                Historique
              </button>
              <button
                type="button"
                onClick={() => setTab("radios")}
                className={[
                  "whitespace-nowrap flex-shrink-0 rounded-2xl px-3 py-2 text-sm font-medium transition-all",
                  tab === "radios"
                    ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-700",
                ].join(" ")}
              >
                Radios/Documents
              </button>
              <button
                type="button"
                onClick={() => setTab("finances")}
                className={[
                  "whitespace-nowrap flex-shrink-0 rounded-2xl px-3 py-2 text-sm font-medium transition-all",
                  tab === "finances"
                    ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-700",
                ].join(" ")}
              >
                Finances
              </button>
            </div>
          </div>

          <div className="mt-5">
            {tab === "historique" && (
              <div>
                <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                  Timeline des consultations
                </h2>
                <div className="mt-4 relative pl-6">
                  <div className="absolute left-2 top-0 bottom-0 w-px bg-slate-200" />
                  <div className="space-y-4">
                    {timeline.map((t, idx) => (
                      <div
                        key={t.date + idx}
                        className="relative flex gap-4"
                      >
                        <div className="absolute left-[-34px] top-0 h-2 w-2 rounded-full bg-[color:var(--ds-primary)] shadow-[0_0_12px_rgba(8,145,178,0.35)]" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-500">
                            {t.date}
                          </p>
                          <p className="mt-1 text-sm font-semibold text-slate-800">
                            {t.titre}
                          </p>
                          <p className="mt-1 text-sm text-slate-600">
                            {t.note}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tab === "radios" && (
              <section className="flex flex-col gap-6">
                {/* En-tête de l'onglet */}
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                    Imagerie &amp; Documents
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setIsPrescriptionModalOpen(true)}
                      className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200/80 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-colors hover:bg-slate-50 hover:border-slate-300/80"
                    >
                      <FileText className="h-4 w-4" />
                      Créer une ordonnance
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[color:var(--ds-primary)] px-4 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:opacity-90"
                    >
                      <Plus className="h-4 w-4" />
                      Ajouter un document
                    </button>
                  </div>
                </div>

                {/* Zone Drag & Drop */}
                <div className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-3xl border-2 border-dashed border-slate-300 bg-slate-50 p-10 transition-colors hover:border-[color:var(--ds-primary)]/50 hover:bg-slate-100/60">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-sm">
                    <UploadCloud className="h-7 w-7 text-[color:var(--ds-primary)]" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-slate-700">
                      Glissez vos radios panoramiques ou fichiers PDF ici
                    </p>
                    <p className="mt-1 text-xs text-slate-400">
                      ou cliquez pour parcourir (Max 10MB)
                    </p>
                  </div>
                </div>

                {/* Galerie des radios */}
                <div>
                  <h3 className="mb-3 text-sm font-semibold text-slate-600">
                    Derniers examens
                  </h3>
                  <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                    {/* Carte Radio 1 */}
                    <div className="flex flex-col gap-2">
                      <div className="group relative aspect-video overflow-hidden rounded-xl bg-slate-200">
                        <div className="flex h-full w-full items-center justify-center">
                          <FileText className="h-10 w-10 text-slate-400" />
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center gap-2 bg-slate-900/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            Voir
                          </button>
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Download className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-slate-700">Panoramique de contrôle</p>
                        <p className="text-xs text-slate-400">18 Mars 2026</p>
                      </div>
                    </div>

                    {/* Carte Radio 2 */}
                    <div className="flex flex-col gap-2">
                      <div className="group relative aspect-video overflow-hidden rounded-xl bg-slate-200">
                        <div className="flex h-full w-full items-center justify-center">
                          <FileText className="h-10 w-10 text-slate-400" />
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center gap-2 bg-slate-900/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            Voir
                          </button>
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Download className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-slate-700">Rétro-alvéolaire dent 36</p>
                        <p className="text-xs text-slate-400">05 Fév 2026</p>
                      </div>
                    </div>

                    {/* Carte Radio 3 */}
                    <div className="flex flex-col gap-2">
                      <div className="group relative aspect-video overflow-hidden rounded-xl bg-slate-200">
                        <div className="flex h-full w-full items-center justify-center">
                          <FileText className="h-10 w-10 text-slate-400" />
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center gap-2 bg-slate-900/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            Voir
                          </button>
                          <button
                            type="button"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow transition-colors hover:bg-slate-50"
                          >
                            <Download className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-slate-700">Bilan initial complet</p>
                        <p className="text-xs text-slate-400">12 Nov 2025</p>
                      </div>
                    </div>
                  </div>
                </div>

                <PrescriptionModal
                  open={isPrescriptionModalOpen}
                  patientName={profile.nom}
                  patientAge={profile.age ? `${profile.age} ans` : "—"}
                  onClose={() => setIsPrescriptionModalOpen(false)}
                  onGeneratePdf={(items: PrescriptionItem[]) => {
                    console.log("Prescription PDF", {
                      patient: profile.nom,
                      items,
                    });
                  }}
                />
              </section>
            )}

            {tab === "finances" && (
              <div>
                <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                  Finances
                </h2>
                <div className="mt-4">
                  <PatientFinanceCard />
                </div>
              </div>
            )}
          </div>
        </section>
      </div>

      {/* ── Slide-over saisie clinique ── */}
      {selectedTooth !== null && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40 bg-slate-900/20 backdrop-blur-sm"
            onClick={() => setSelectedTooth(null)}
          />

          {/* Panneau latéral */}
          <div className="fixed inset-y-0 right-0 z-50 flex w-full max-w-md transform flex-col bg-white shadow-2xl transition-transform duration-300">
            {/* En-tête */}
            <div className="flex items-center justify-between border-b border-slate-100 p-6">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                  Saisie Clinique
                </p>
                <h2 className="mt-0.5 text-lg font-semibold text-[color:var(--ds-text)]">
                  Dent {selectedTooth}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTooth(null)}
                className="flex h-9 w-9 items-center justify-center rounded-2xl text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
                aria-label="Fermer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Catégories (pilules) */}
            <div className="flex gap-2 overflow-x-auto px-6 py-4 pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {["Saine", "Soins", "Orthopédie", "Chirurgie", "Absente"].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setToothCategory(cat)}
                  className={[
                    "shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                    toothCategory === cat
                      ? cat === "Saine"
                        ? "bg-slate-200 text-slate-800 shadow-sm"
                        : "bg-[color:var(--ds-primary)] text-white shadow-sm"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                  ].join(" ")}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Formulaire */}
            <div className="flex-1 space-y-5 overflow-y-auto p-6">
              {/* Acte — filtré selon la catégorie sélectionnée */}
              {toothCategory !== "Saine" && (
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-500">
                    Acte réalisé
                  </label>
                  <select
                    value={toothActe}
                    onChange={(e) => setToothActe(e.target.value)}
                    disabled={!toothCategory}
                    className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm text-slate-700 transition-colors focus:border-[color:var(--ds-primary)] focus:outline-none focus:ring-2 focus:ring-[color:var(--ds-primary)]/20 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="">— Choisir un acte —</option>
                    {(ACTES_PAR_CATEGORIE[toothCategory] ?? []).map((acte) => (
                      <option key={acte} value={acte}>
                        {acte}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Longueur de travail */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-500">
                  LT (Longueur de Travail) en mm
                </label>
                <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 transition-colors focus-within:border-[color:var(--ds-primary)] focus-within:ring-2 focus-within:ring-[color:var(--ds-primary)]/20">
                  <input
                    type="number"
                    min="0"
                    max="30"
                    step="0.5"
                    value={toothLT}
                    onChange={(e) => setToothLT(e.target.value)}
                    placeholder="ex : 21.5"
                    className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-300"
                  />
                  <span className="shrink-0 text-xs font-medium text-slate-400">mm</span>
                </div>
              </div>

              {/* Notes cliniques */}
              {toothCategory !== "Saine" && (
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-500">
                    Notes cliniques
                  </label>
                  <textarea
                    value={toothNotes}
                    onChange={(e) => setToothNotes(e.target.value)}
                    rows={5}
                    placeholder="Observations, complications, plan de suivi…"
                    className="w-full resize-none rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 transition-colors placeholder:text-slate-300 focus:border-[color:var(--ds-primary)] focus:outline-none focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
                  />
                </div>
              )}
            </div>

            {/* Pied de page */}
            <div className="flex items-center justify-end gap-3 border-t border-slate-100 bg-slate-50 p-6">
              <button
                type="button"
                onClick={() => setSelectedTooth(null)}
                className="rounded-2xl px-5 py-2.5 text-sm font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  if (selectedTooth !== null) {
                    if (toothCategory === "Saine") {
                      // Dent saine = redevient healthy + suppression timeline
                      setDentsStatus((prev) => ({
                        ...prev,
                        [selectedTooth as ToothId]: "healthy",
                      }));
                      setAllTreatments((prev) =>
                        prev.filter((t) => t.tooth !== selectedTooth)
                      );
                    } else {
                      const newStatus: ToothStatus =
                        CATEGORY_TO_STATUS[toothCategory] ?? "healthy";
                      setDentsStatus((prev) => ({
                        ...prev,
                        [selectedTooth as ToothId]: newStatus,
                      }));
                      const nouvelActe = {
                        tooth: selectedTooth,
                        category: toothCategory,
                        acte: toothActe || toothCategory,
                        date: "Aujourd'hui",
                        notes: toothNotes || undefined,
                        lt: toothLT || undefined,
                      };

                      setAllTreatments((prev) => {
                        const exists = prev.some(
                          (t) => t.tooth === selectedTooth
                        );
                        if (exists) {
                          return prev.map((t) =>
                            t.tooth === selectedTooth ? nouvelActe : t
                          );
                        }
                        return [nouvelActe, ...prev];
                      });
                    }
                  }
                  setSelectedTooth(null);
                  setToothCategory("");
                  setToothActe("");
                  setToothLT("");
                  setToothNotes("");
                }}
                className="rounded-2xl bg-[color:var(--ds-primary)] px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:opacity-90"
              >
                {existingTreatmentForSelectedTooth ? "Mettre à jour" : "Enregistrer"}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}


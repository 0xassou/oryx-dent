"use client";

import { useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, GitBranch, Plus } from "lucide-react";
import {
  NewAppointmentModal,
  type NewAppointmentPayload,
} from "@/components/planning/NewAppointmentModal";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Rdv {
  id: string;
  day: number;      // 0 = lundi … 6 = dimanche
  start: string;
  durationMinutes: number;
  patient: string;
  soin: string;
  urgence?: boolean;
}

type ViewMode = "calendar" | "tree";

// ─── Helpers date ─────────────────────────────────────────────────────────────

function getMonday(d: Date): Date {
  const date = new Date(d);
  const day = date.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function formatDateInput(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function formatDateLong(d: Date): string {
  return d.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function getDayOfWeek(d: Date): number {
  const day = d.getDay();
  return day === 0 ? 6 : day - 1;
}

// ─── Données fictives ─────────────────────────────────────────────────────────

const WEEK_DAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

const RDV: Rdv[] = [
  { id: "1", day: 0, start: "08:30", durationMinutes: 30,  patient: "Marie Dupont",    soin: "Détartrage"    },
  { id: "2", day: 0, start: "10:00", durationMinutes: 45,  patient: "Jean Martin",     soin: "Extraction",   urgence: true },
  { id: "3", day: 0, start: "11:30", durationMinutes: 60,  patient: "Isabelle Roux",   soin: "Couronne"      },
  { id: "4", day: 0, start: "14:00", durationMinutes: 90,  patient: "Sophie Bernard",  soin: "Blanchiment"   },
  { id: "5", day: 1, start: "09:00", durationMinutes: 30,  patient: "Pierre Leroy",    soin: "Détartrage"    },
  { id: "6", day: 1, start: "14:30", durationMinutes: 45,  patient: "Lucas Garnier",   soin: "Consultation"  },
  { id: "7", day: 2, start: "10:30", durationMinutes: 60,  patient: "Claire Moreau",   soin: "Implant",      urgence: true },
  { id: "8", day: 3, start: "09:30", durationMinutes: 30,  patient: "Thomas Petit",    soin: "Blanchiment"   },
  { id: "9", day: 4, start: "11:00", durationMinutes: 45,  patient: "Marie Dupont",    soin: "Contrôle"      },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function rdvColor(rdv: Rdv) {
  return rdv.urgence
    ? { bg: "bg-red-50", text: "text-red-600", dot: "bg-red-400", border: "border-red-200/60" }
    : { bg: "bg-[color:var(--ds-primary-soft)]/60", text: "text-[color:var(--ds-primary)]", dot: "bg-cyan-400", border: "border-cyan-200/40" };
}

// ─── Vue 1 : Calendrier hebdomadaire ─────────────────────────────────────────

function CalendarView({
  rdvs,
  weekDates,
}: {
  rdvs: Rdv[];
  weekDates: number[];
}) {
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropDay, setDropDay] = useState<number | null>(null);
  const [items, setItems] = useState<Rdv[]>(rdvs);

  function handleDrop(day: number) {
    if (dragId === null) return;
    setItems((prev) =>
      prev.map((r) => (r.id === dragId ? { ...r, day } : r))
    );
    setDragId(null);
    setDropDay(null);
  }

  return (
    <div className="rounded-3xl bg-white shadow-[0_8px_30px_rgba(0,0,0,0.04)] overflow-hidden">
      <div className="overflow-x-auto flex flex-nowrap snap-x snap-mandatory min-h-[420px] [scrollbar-gutter:stable]">
        {WEEK_DAYS.map((_, dayIdx) => {
          const dayRdvs = items.filter((r) => r.day === dayIdx);
          const isOver = dropDay === dayIdx;
          return (
            <div
              key={dayIdx}
              className="snap-start shrink-0 min-w-[250px] flex flex-col border-r border-slate-100 last:border-0"
            >
              {/* En-tête du jour */}
              <div className="shrink-0 border-b border-slate-100 px-3 py-3 text-center">
                <p className="text-[11px] font-medium tracking-tight text-slate-400 uppercase">
                  {WEEK_DAYS[dayIdx]}
                </p>
                <p className="mt-0.5 text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                  {weekDates[dayIdx]}
                </p>
              </div>
              {/* Zone de dépôt + blocs */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDropDay(dayIdx); }}
                onDragLeave={() => setDropDay(null)}
                onDrop={() => handleDrop(dayIdx)}
                className={[
                  "min-h-[380px] p-2 flex flex-col gap-1.5 transition-colors flex-1",
                  isOver ? "bg-cyan-50/60" : "",
                ].join(" ")}
              >
                {dayRdvs.map((rdv) => {
                  const c = rdvColor(rdv);
                  return (
                    <div
                      key={rdv.id}
                      draggable
                      onDragStart={() => setDragId(rdv.id)}
                      onDragEnd={() => { setDragId(null); setDropDay(null); }}
                      className={[
                        "cursor-grab active:cursor-grabbing select-none",
                        "rounded-xl border px-2 py-1.5 backdrop-blur-sm",
                        "shadow-[0_8px_30px_rgba(0,0,0,0.04)] transition-opacity",
                        c.bg, c.border,
                        dragId === rdv.id ? "opacity-40" : "opacity-100",
                      ].join(" ")}
                    >
                      <div className="flex items-center gap-1.5">
                        <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${c.dot}`} />
                        <p className="truncate text-[11px] font-semibold tracking-tight text-[color:var(--ds-text)]">
                          {rdv.patient}
                        </p>
                      </div>
                      <p className={`mt-0.5 truncate text-[10px] font-medium ${c.text}`}>
                        {rdv.start} · {rdv.soin}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Vue 2 : Timeline Arbre ───────────────────────────────────────────────────

function TreeView({ rdvs, currentDate }: { rdvs: Rdv[]; currentDate: Date }) {
  const dayOfWeek = getDayOfWeek(currentDate);
  const dayLabel = formatDateLong(currentDate);
  const todayRdvs = rdvs.filter((r) => r.day === dayOfWeek);
  const matin = todayRdvs.filter((r) => Number(r.start.split(":")[0]) < 12);
  const apresmidi = todayRdvs.filter((r) => Number(r.start.split(":")[0]) >= 12);

  function actBg(soin: string) {
    const s = soin.toLowerCase();
    if (s.includes("détartr")) return "bg-[color:var(--ds-primary-soft)]/60";
    if (s.includes("extract")) return "bg-red-50/70";
    if (s.includes("couronne") || s.includes("implant") || s.includes("proth"))
      return "bg-amber-50/80";
    if (s.includes("blanch")) return "bg-sky-50/70";
    return "bg-slate-50/70";
  }

  function Branch({
    label,
    items,
  }: {
    label: string;
    items: Rdv[];
  }) {
    return (
      <div className="relative mt-4 pl-12">
        {/* Tronc */}
        <div className="absolute left-3 top-0 bottom-0 w-px bg-gradient-to-b from-cyan-300/60 via-teal-300/40 to-transparent" />

        {/* Label branche */}
        <div className="relative mb-4 flex items-center gap-6">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-teal-400 shadow-[0_0_12px_rgba(34,211,238,0.35)]">
            <span className="h-1.5 w-1.5 rounded-full bg-white" />
          </span>
          <h3 className="text-xs font-semibold uppercase tracking-widest text-slate-500">
            {label}
          </h3>
        </div>

        {/* Feuilles (RDV) */}
        <div className="space-y-3 pl-4">
          {items.length === 0 && (
            <p className="text-xs text-slate-400">Aucun rendez-vous</p>
          )}
          {items.map((rdv) => {
            const c = rdvColor(rdv);
            return (
              <div key={rdv.id} className="relative flex items-start gap-4">
                {/* Branche horizontale */}
                <div className="absolute -left-4 top-4 h-px w-4 bg-gradient-to-r from-cyan-300/50 to-transparent" />
                {/* Point lumineux */}
                <span
                  className={[
                    "mt-3.5 h-2.5 w-2.5 shrink-0 rounded-full ring-2 ring-white shadow-[0_0_8px_rgba(34,211,238,0.5)]",
                    c.dot,
                  ].join(" ")}
                />
                {/* Carte feuille */}
                <div
                  className={[
                    "flex-1 rounded-2xl border px-4 py-3",
                    "shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-sm",
                    actBg(rdv.soin),
                    c.border,
                  ].join(" ")}
                >
                  {/* Heure en premier, reliée visuellement à la branche */}
                  <div className="flex items-center gap-3">
                    <p className="text-sm font-semibold tracking-tight text-slate-700">
                      {rdv.start}
                    </p>
                    <div className="h-px flex-1 rounded-full bg-slate-200/70" />
                  </div>

                  <div className="mt-1 flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold tracking-tight text-[color:var(--ds-text)]">
                        {rdv.patient}
                      </p>
                      <p className={`mt-0.5 text-[11px] font-medium ${c.text}`}>
                        {rdv.soin}
                      </p>
                    </div>
                    <p className="mt-0.5 text-[10px] text-slate-400">
                      {rdv.durationMinutes} min
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.04)] space-y-8">
      {/* Tronc principal */}
      <div className="relative pl-12">
        <div className="absolute left-3 top-0 bottom-0 w-0.5 rounded-full bg-gradient-to-b from-cyan-300/80 via-teal-200/50 to-transparent" />
        <div className="relative mb-6 flex items-center gap-6">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 to-teal-500 shadow-[0_0_18px_rgba(8,145,178,0.35)]">
            <span className="h-2 w-2 rounded-full bg-white" />
          </span>
          <p className="text-sm font-semibold tracking-tight text-[color:var(--ds-text)]">
            {dayLabel}
          </p>
          <span className="rounded-full bg-cyan-50 px-2.5 py-0.5 text-[11px] font-medium text-[color:var(--ds-primary)]">
            {todayRdvs.length} RDV
          </span>
        </div>

        <div className="mt-2 space-y-8 pl-4 pr-3 max-h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-slate-100">
          <Branch label="Matin" items={matin} />
          <Branch label="Après-midi" items={apresmidi} />
        </div>
      </div>
    </div>
  );
}

// ─── Page principale ──────────────────────────────────────────────────────────

function getWeekDatesFromMonday(monday: Date): number[] {
  return [0, 1, 2, 3, 4, 5, 6].map((i) => {
    const d = new Date(monday);
    d.setDate(d.getDate() + i);
    return d.getDate();
  });
}

function formatWeekRange(currentDate: Date): string {
  const mon = getMonday(currentDate);
  const sun = new Date(mon);
  sun.setDate(sun.getDate() + 6);
  const monthYear = mon.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
  return `Semaine du ${mon.getDate()} au ${sun.getDate()} ${monthYear}`;
}

export default function PlanningPage() {
  const [view, setView] = useState<ViewMode>("calendar");
  const [currentDate, setCurrentDate] = useState<Date>(() => new Date());
  const [isNewRdvModalOpen, setIsNewRdvModalOpen] = useState(false);

  const weekStart = getMonday(currentDate);
  const weekDates = getWeekDatesFromMonday(weekStart);

  function goPrev() {
    setCurrentDate((d) => {
      const next = new Date(d);
      next.setDate(next.getDate() - 1);
      return next;
    });
  }
  function goNext() {
    setCurrentDate((d) => {
      const next = new Date(d);
      next.setDate(next.getDate() + 1);
      return next;
    });
  }
  function goToday() {
    setCurrentDate(new Date());
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-col gap-3">
          <h1 className="text-2xl font-semibold tracking-tight text-[color:var(--ds-text)]">
            Planning
          </h1>
          <p className="text-xs text-slate-500">
            {formatWeekRange(currentDate)} — {RDV.length} rendez-vous
          </p>
          {/* Barre de navigation temporelle */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={goPrev}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200/60 bg-white/80 shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-md transition-colors hover:bg-slate-50 hover:border-slate-300/60"
              aria-label="Jour précédent"
            >
              <ChevronLeft className="h-4 w-4 text-slate-600" />
            </button>
            <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200/60 bg-white/80 px-3 py-2 shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-md transition-colors hover:bg-slate-50 hover:border-slate-300/60">
              <span className="text-base" aria-hidden>📅</span>
              <input
                type="date"
                value={formatDateInput(currentDate)}
                onChange={(e) => {
                  const v = e.target.value;
                  if (v) {
                    const [y, m, d] = v.split("-").map(Number);
                    setCurrentDate(new Date(y, m - 1, d));
                  }
                }}
                className="min-w-[140px] border-0 bg-transparent text-sm font-medium text-[color:var(--ds-text)] outline-none [color-scheme:light]"
              />
            </label>
            <button
              type="button"
              onClick={goNext}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200/60 bg-white/80 shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-md transition-colors hover:bg-slate-50 hover:border-slate-300/60"
              aria-label="Jour suivant"
            >
              <ChevronRight className="h-4 w-4 text-slate-600" />
            </button>
            <button
              type="button"
              onClick={goToday}
              className="rounded-xl border border-slate-200/60 bg-white/80 px-3 py-2 text-xs font-medium text-[color:var(--ds-text)] shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-md transition-colors hover:bg-slate-50 hover:border-slate-300/60"
            >
              Aujourd&apos;hui
            </button>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* Switcher de vues */}
          <div className="flex rounded-2xl border border-slate-200/60 bg-white p-1 shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-md">
            <button
              type="button"
              onClick={() => setView("calendar")}
              className={[
                "flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium transition-all",
                view === "calendar"
                  ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-700",
              ].join(" ")}
            >
              <CalendarDays className="h-3.5 w-3.5" />
              Calendrier
            </button>
            <button
              type="button"
              onClick={() => setView("tree")}
              className={[
                "flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium transition-all",
                view === "tree"
                  ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-700",
              ].join(" ")}
            >
              <GitBranch className="h-3.5 w-3.5" />
              Vue Arbre
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsNewRdvModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[color:var(--ds-primary)] px-4 py-2.5 text-xs font-medium text-white shadow-[0_8px_30px_rgba(0,0,0,0.04)] transition-colors hover:opacity-90"
          >
            <Plus className="h-3.5 w-3.5" />
            Nouveau RDV
          </button>
        </div>
      </div>

      <NewAppointmentModal
        open={isNewRdvModalOpen}
        onClose={() => setIsNewRdvModalOpen(false)}
        onConfirm={(payload: NewAppointmentPayload) => {
          console.log("NewAppointment", payload);
          setIsNewRdvModalOpen(false);
        }}
      />

      {/* Contenu de la vue sélectionnée */}
      {view === "calendar" ? (
        <CalendarView rdvs={RDV} weekDates={weekDates} />
      ) : (
        <TreeView rdvs={RDV} currentDate={currentDate} />
      )}
    </div>
  );
}

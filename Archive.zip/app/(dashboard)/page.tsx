import {
  Users,
  AlertCircle,
  Euro,
  MessageSquare,
  Bell,
  Check,
} from "lucide-react";

const STATS = [
  {
    label: "Patients du jour",
    value: "12",
    icon: Users,
    color: "bg-sky-100 text-sky-600",
  },
  {
    label: "Urgences",
    value: "2",
    icon: AlertCircle,
    color: "bg-amber-100 text-amber-600",
  },
  {
    label: "Chiffre d'affaires",
    value: "2 450 €",
    icon: Euro,
    color: "bg-teal-100 text-teal-600",
  },
  {
    label: "Nouveaux messages",
    value: "5",
    icon: MessageSquare,
    color: "bg-sky-100 text-sky-600",
  },
] as const;

const DERNIERES_CONSULTATIONS = [
  { patient: "Marie Dupont", soin: "Détartrage", date: "Aujourd'hui" },
  { patient: "Jean Martin", soin: "Extraction", date: "Aujourd'hui" },
  { patient: "Sophie Bernard", soin: "Couronne", date: "Hier" },
  { patient: "Pierre Leroy", soin: "Détartrage", date: "Hier" },
  { patient: "Claire Moreau", soin: "Blanchiment", date: "Hier" },
  { patient: "Thomas Petit", soin: "Extraction", date: "Il y a 2 jours" },
];

const PATIENTS_SUIVI = [
  { patient: "M. Benali", soin: "Endodontie", statut: "urgence", progression: 60 },
  { patient: "Mme Dupont", soin: "Détartrage", statut: "fini", progression: 100 },
  { patient: "M. Martin", soin: "Couronne", statut: "fini", progression: 80 },
  { patient: "Mme Roux", soin: "Extraction", statut: "urgence", progression: 40 },
  { patient: "M. Leroy", soin: "Implant", statut: "fini", progression: 55 },
] as const;

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Bannière de bienvenue */}
      <div className="rounded-3xl bg-gradient-to-r from-sky-500 to-teal-500 px-6 py-5 text-white shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
        <h1 className="text-2xl font-semibold tracking-tight text-[color:var(--ds-bg)]">
          Bonjour Dr. Assil
        </h1>
        <p className="mt-1 text-sm text-sky-100">
          Voici un aperçu de votre activité aujourd'hui.
        </p>
      </div>

      {/* Cartes de statistiques */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className={[
                "relative overflow-hidden rounded-3xl p-6",
                "bg-gradient-to-br from-white/80 via-white/60 to-sky-50/40",
                "backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,0.04)]",
                "ring-1 ring-white/60 transition-transform hover:-translate-y-0.5",
              ].join(" ")}
            >
              <div className="pointer-events-none absolute inset-0 opacity-70">
                <div className="absolute -left-16 -top-16 h-40 w-40 rounded-full bg-sky-200/40 blur-2xl" />
                <div className="absolute -bottom-16 -right-16 h-40 w-40 rounded-full bg-teal-200/30 blur-2xl" />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium tracking-wide text-slate-500">
                    {stat.label}
                  </p>
                  <p className="mt-2 text-2xl font-bold tracking-wide text-slate-900">
                    {stat.value}
                  </p>
                </div>
                <div className={`rounded-2xl p-2.5 ${stat.color} ring-1 ring-white/60`}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tableau Dernières consultations */}
      <div className="rounded-3xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
        <h2 className="text-lg font-semibold tracking-tight text-[color:var(--ds-text)]">
          Dernières consultations
        </h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[400px]">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Patient
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Type de soin
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Date
                </th>
              </tr>
            </thead>
            <tbody>
              {DERNIERES_CONSULTATIONS.map((consultation, index) => (
                <tr
                  key={index}
                  className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50"
                >
                  <td className="py-4 text-sm font-medium text-slate-800">
                    {consultation.patient}
                  </td>
                  <td className="py-4 text-sm text-slate-600">
                    {consultation.soin}
                  </td>
                  <td className="py-4 text-sm text-slate-500">
                    {consultation.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Suivi patients (style monitoring) */}
      <div className="rounded-3xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold tracking-tight text-[color:var(--ds-text)]">
            Suivi patients
          </h2>
          <span className="text-xs text-slate-500">Aujourd'hui</span>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[640px]">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Patient
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Type de soin
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Statut
                </th>
                <th className="pb-3 text-left text-sm font-medium text-slate-500">
                  Progression
                </th>
              </tr>
            </thead>
            <tbody>
              {PATIENTS_SUIVI.map((row) => (
                <tr
                  key={row.patient}
                  className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50"
                >
                  <td className="py-4 text-sm font-medium text-slate-800">
                    {row.patient}
                  </td>
                  <td className="py-4 text-sm text-slate-600">{row.soin}</td>
                  <td className="py-4">
                    {row.statut === "urgence" ? (
                      <span className="relative inline-flex h-7 w-7 items-center justify-center">
                        <span className="absolute inset-0 rounded-full bg-red-500/20 blur-md" />
                        <span className="absolute inset-0 rounded-full bg-red-400/20 blur-lg animate-pulse" />
                        <span
                          className="relative inline-flex h-7 w-7 items-center justify-center rounded-full bg-white/70 text-red-600 ring-1 ring-red-200/70 shadow-[0_0_0_1px_rgba(239,68,68,0.12),0_10px_30px_rgba(239,68,68,0.12)]"
                          aria-label="Urgence"
                          title="Urgence"
                        >
                          <Bell className="h-4 w-4" />
                        </span>
                      </span>
                    ) : (
                      <span
                        className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-white/70 text-teal-700 ring-1 ring-teal-200/70"
                        aria-label="Traitement fini"
                        title="Traitement fini"
                      >
                        <Check className="h-4 w-4" />
                      </span>
                    )}
                  </td>
                  <td className="py-4">
                    <div className="flex items-center gap-3">
                      <div className="h-2.5 w-44 rounded-full bg-slate-100/80 ring-1 ring-white/70">
                        <div
                          className="h-2.5 rounded-full bg-gradient-to-r from-sky-500 to-teal-500"
                          style={{ width: `${row.progression}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium text-slate-500">
                        {row.progression}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Clock,
  MoreVertical,
  Package,
  Plus,
  Search,
  X,
} from "lucide-react";

type Categorie = "Composites" | "Anesthésiques" | "Consommables" | "Implants";
type Statut = "En stock" | "Faible" | "Rupture";

interface Produit {
  id: string;
  nom: string;
  categorie: Categorie;
  quantite: number;
  quantiteMax: number;
  peremption: string; // format d'affichage: DD/MM/YYYY ou "—"
}

const CATEGORIES: Categorie[] = [
  "Composites",
  "Anesthésiques",
  "Consommables",
  "Implants",
];

const INITIAL_PRODUITS: Produit[] = [
  {
    id: "1",
    nom: "Résine Composite A2 - Filtek",
    categorie: "Composites",
    quantite: 34,
    quantiteMax: 50,
    peremption: "12/10/2026",
  },
  {
    id: "2",
    nom: "Résine Composite B1 - Filtek",
    categorie: "Composites",
    quantite: 8,
    quantiteMax: 50,
    peremption: "05/08/2026",
  },
  {
    id: "3",
    nom: "Articaïne 4% - Septanest",
    categorie: "Anesthésiques",
    quantite: 120,
    quantiteMax: 200,
    peremption: "22/01/2027",
  },
  {
    id: "4",
    nom: "Lidocaïne 2% - Xylocaïne",
    categorie: "Anesthésiques",
    quantite: 0,
    quantiteMax: 100,
    peremption: "—",
  },
  {
    id: "5",
    nom: "Gants nitrile (M) - Medicom",
    categorie: "Consommables",
    quantite: 450,
    quantiteMax: 500,
    peremption: "30/06/2027",
  },
  {
    id: "6",
    nom: "Masques chirurgicaux - Kolmi",
    categorie: "Consommables",
    quantite: 15,
    quantiteMax: 200,
    peremption: "15/04/2026",
  },
  {
    id: "7",
    nom: "Implant Straumann BLT Ø4.1",
    categorie: "Implants",
    quantite: 6,
    quantiteMax: 20,
    peremption: "18/12/2027",
  },
  {
    id: "8",
    nom: "Implant Nobel Active Ø3.5",
    categorie: "Implants",
    quantite: 0,
    quantiteMax: 15,
    peremption: "—",
  },
  {
    id: "9",
    nom: "Ciment verre-ionomère - GC Fuji",
    categorie: "Composites",
    quantite: 22,
    quantiteMax: 40,
    peremption: "09/09/2026",
  },
  {
    id: "10",
    nom: "Rouleaux de coton salivaire",
    categorie: "Consommables",
    quantite: 3,
    quantiteMax: 300,
    peremption: "01/05/2026",
  },
  {
    id: "11",
    nom: "Anesthésique topique - Hurricaine",
    categorie: "Anesthésiques",
    quantite: 18,
    quantiteMax: 30,
    peremption: "20/11/2026",
  },
  {
    id: "12",
    nom: "Pilier implantaire Ø4.1",
    categorie: "Implants",
    quantite: 0,
    quantiteMax: 10,
    peremption: "—",
  },
];

function uid() {
  return Math.random().toString(16).slice(2);
}

function parsePeremptionDisplayToIso(display: string): string {
  if (!display || display === "—") return "";
  const parts = display.split("/");
  if (parts.length !== 3) return "";
  const [dd, mm, yyyy] = parts;
  if (!dd || !mm || !yyyy) return "";
  return `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
}

function formatPeremptionIsoToDisplay(iso: string): string {
  if (!iso) return "—";
  const parts = iso.split("-");
  if (parts.length !== 3) return "—";
  const [yyyy, mm, dd] = parts;
  return `${dd}/${mm}/${yyyy}`;
}

function parsePeremptionDisplayToDate(display: string): Date | null {
  if (!display || display === "—") return null;
  const iso = parsePeremptionDisplayToIso(display);
  if (!iso) return null;
  const d = new Date(iso + "T12:00:00");
  return Number.isNaN(d.getTime()) ? null : d;
}

function getPct(p: Produit) {
  if (p.quantiteMax <= 0) return 0;
  return (p.quantite / p.quantiteMax) * 100;
}

function computeStatut(p: Produit): Statut {
  const pct = getPct(p);
  if (pct === 0) return "Rupture";
  if (pct < 50) return "Faible";
  return "En stock";
}

function progressBarClass(p: Produit) {
  const pct = getPct(p);
  if (pct === 0) return "bg-red-400";
  if (pct < 20) return "bg-amber-400";
  if (pct > 50) return "bg-emerald-400";
  return "bg-amber-400";
}

function badgeClass(statut: Statut) {
  switch (statut) {
    case "En stock":
      return "bg-emerald-50 text-emerald-700";
    case "Faible":
      return "bg-amber-50 text-amber-700";
    case "Rupture":
      return "bg-red-50 text-red-600";
  }
}

function peremptionProcheCount(produits: Produit[]) {
  const thresholdDays = 210; // ~7 mois, pour un rendu stable sur la maquette
  const now = new Date();
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() + thresholdDays);

  return produits.filter((p) => {
    const d = parsePeremptionDisplayToDate(p.peremption);
    if (!d) return false;
    return d >= now && d <= cutoff;
  }).length;
}

interface ProductModalProps {
  open: boolean;
  mode: "create" | "edit";
  product?: Produit | null;
  onClose: () => void;
  onSave: (draft: Omit<Produit, "id">, id?: string) => void;
}

function ProductModal({
  open,
  mode,
  product,
  onClose,
  onSave,
}: ProductModalProps) {
  const [nom, setNom] = useState("");
  const [categorie, setCategorie] = useState<Categorie>("Composites");
  const [quantite, setQuantite] = useState<number>(0);
  const [quantiteMax, setQuantiteMax] = useState<number>(0);
  const [peremptionIso, setPeremptionIso] = useState<string>("");

  useEffect(() => {
    if (!open) return;
    const defaultPeremption = (() => {
      const d = new Date();
      d.setDate(d.getDate() + 180);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    })();

    setNom(product?.nom ?? "");
    setCategorie(product?.categorie ?? "Composites");
    setQuantite(product?.quantite ?? 0);
    setQuantiteMax(product?.quantiteMax ?? 0);
    setPeremptionIso(parsePeremptionDisplayToIso(product?.peremption ?? "—") || defaultPeremption);
  }, [open, product]);

  if (!open) return null;

  function handleCancel() {
    onClose();
  }

  function handleSubmit() {
    const trimmedNom = nom.trim();
    if (!trimmedNom) return;

    const draft: Omit<Produit, "id"> = {
      nom: trimmedNom,
      categorie,
      quantite: Number.isFinite(quantite) ? quantite : 0,
      quantiteMax: Number.isFinite(quantiteMax) ? quantiteMax : 0,
      peremption: formatPeremptionIsoToDisplay(peremptionIso),
    };

    onSave(draft, product?.id);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={mode === "create" ? "Ajouter un produit" : "Modifier un produit"}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="w-full max-w-2xl rounded-3xl bg-white/95 shadow-[0_8px_30px_rgba(0,0,0,0.08)] backdrop-blur-md"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-slate-200/60 px-6 py-4">
          <div>
            <h3 className="text-lg font-semibold tracking-tight text-[color:var(--ds-text)]">
              {mode === "create" ? "Ajouter un produit" : "Modifier le produit"}
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Renseignez les informations requises.
            </p>
          </div>
          <button
            type="button"
            onClick={handleCancel}
            className="rounded-xl p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700"
            aria-label="Fermer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="px-6 py-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-slate-700">
                Nom du produit
              </label>
              <input
                type="text"
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors placeholder:text-slate-400 focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
                placeholder="Ex: Résine Composite A2 - Filtek"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Catégorie
              </label>
              <select
                value={categorie}
                onChange={(e) => setCategorie(e.target.value as Categorie)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Quantité Actuelle
              </label>
              <input
                type="number"
                min={0}
                value={quantite}
                onChange={(e) => setQuantite(Number(e.target.value))}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Quantité Max/Idéale
              </label>
              <input
                type="number"
                min={0}
                value={quantiteMax}
                onChange={(e) => setQuantiteMax(Number(e.target.value))}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-700">
                Date de péremption
              </label>
              <input
                type="date"
                value={peremptionIso}
                onChange={(e) => setPeremptionIso(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 border-t border-slate-200/60 px-6 py-4">
          <button
            type="button"
            onClick={handleCancel}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-colors hover:bg-slate-50"
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="rounded-xl bg-[color:var(--ds-primary)] px-4 py-2.5 text-sm font-medium text-white shadow-[0_8px_30px_rgba(0,0,0,0.08)] transition-colors hover:opacity-90"
          >
            Enregistrer
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StocksPage() {
  const [produits, setProduits] = useState<Produit[]>(INITIAL_PRODUITS);
  const [search, setSearch] = useState("");
  const [filtre, setFiltre] = useState<Categorie | "">("");
  const [openActionsId, setOpenActionsId] = useState<string | null>(null);

  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Produit | null>(null);
  const modalMode = editingProduct ? "edit" : "create";

  const filtered = useMemo(() => {
    return produits.filter((p) => {
      const matchSearch =
        search === "" ||
        p.nom.toLowerCase().includes(search.toLowerCase());
      const matchCat = filtre === "" || p.categorie === filtre;
      return matchSearch && matchCat;
    });
  }, [produits, search, filtre]);

  const totalProduits = produits.length;
  const enRupture = produits.filter(
    (p) => computeStatut(p) === "Rupture",
  ).length;
  const peremptionProche = peremptionProcheCount(produits);

  function openCreateModal() {
    setEditingProduct(null);
    setIsProductModalOpen(true);
    setOpenActionsId(null);
  }

  function openEditModal(product: Produit) {
    setEditingProduct(product);
    setIsProductModalOpen(true);
    setOpenActionsId(null);
  }

  function handleSaveProduct(draft: Omit<Produit, "id">, id?: string) {
    if (id) {
      setProduits((prev) =>
        prev.map((p) => (p.id === id ? { ...p, ...draft } : p)),
      );
    } else {
      const newId = `p-${uid()}`;
      setProduits((prev) => [{ id: newId, ...draft }, ...prev]);
    }
    setIsProductModalOpen(false);
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[color:var(--ds-text)]">
            Gestion des Stocks
          </h1>
          <p className="mt-1 text-xs text-slate-500">
            Vue d&apos;ensemble du matériel et des consommables
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[color:var(--ds-primary)] px-4 py-2.5 text-xs font-medium text-white shadow-sm transition-colors hover:opacity-90"
        >
          <Plus className="h-4 w-4" />
          Ajouter un produit
        </button>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-sm">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-50 text-[color:var(--ds-primary)]">
            <Package className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] font-medium tracking-tight text-slate-500">
              Total Produits
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-[color:var(--ds-text)]">
              {totalProduits}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-sm">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-500">
            <AlertTriangle className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] font-medium tracking-tight text-slate-500">
              En rupture
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-red-600">
              {enRupture}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-sm">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-500">
            <Clock className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] font-medium tracking-tight text-slate-500">
              Péremption proche
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-amber-600">
              {peremptionProche}
            </p>
          </div>
        </div>
      </div>

      {/* Recherche & Filtres */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un produit…"
            className="w-full rounded-xl border border-slate-200 bg-white/80 py-2.5 pl-9 pr-3 text-sm text-slate-800 outline-none transition-colors placeholder:text-slate-400 focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
          />
        </div>
        <select
          value={filtre}
          onChange={(e) => setFiltre(e.target.value as Categorie | "")}
          className="rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-sm text-slate-700 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
        >
          <option value="">Toutes les catégories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Tableau */}
      <div className="rounded-2xl bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-5 py-3.5 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Produit
                </th>
                <th className="px-5 py-3.5 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Quantité
                </th>
                <th className="px-5 py-3.5 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Statut
                </th>
                <th className="px-5 py-3.5 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Péremption
                </th>
                <th className="px-5 py-3.5 text-right text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const pct =
                  p.quantiteMax > 0
                    ? Math.round((p.quantite / p.quantiteMax) * 100)
                    : 0;
                const statut = computeStatut(p);
                const isActionsOpen = openActionsId === p.id;

                return (
                  <tr
                    key={p.id}
                    className="border-b border-slate-50 last:border-0 transition-colors hover:bg-slate-50/60"
                  >
                    {/* Produit */}
                    <td className="px-5 py-4">
                      <p className="text-sm font-medium text-slate-800">
                        {p.nom}
                      </p>
                      <p className="mt-0.5 text-[11px] text-slate-500">
                        {p.categorie}
                      </p>
                    </td>

                    {/* Quantité (jauge) */}
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-2 w-24 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className={`h-full rounded-full transition-all ${progressBarClass(p)}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold tabular-nums text-slate-700">
                          {p.quantite}/{p.quantiteMax}
                        </span>
                      </div>
                    </td>

                    {/* Statut */}
                    <td className="px-5 py-4">
                      <span
                        className={`inline-flex rounded-lg px-2.5 py-0.5 text-[11px] font-medium ${badgeClass(statut)}`}
                      >
                        {statut}
                      </span>
                    </td>

                    {/* Péremption */}
                    <td className="px-5 py-4 text-sm text-slate-600">
                      {p.peremption}
                    </td>

                    {/* Actions */}
                    <td className="relative px-5 py-4 text-right">
                      <button
                        type="button"
                        onClick={() =>
                          setOpenActionsId(isActionsOpen ? null : p.id)
                        }
                        className="inline-flex h-8 w-8 items-center justify-center rounded-xl text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700"
                        aria-label={`Actions pour ${p.nom}`}
                      >
                        <MoreVertical className="h-4 w-4" />
                      </button>

                      {isActionsOpen && (
                        <>
                          <div
                            className="fixed inset-0 z-40"
                            aria-hidden="true"
                            onClick={() => setOpenActionsId(null)}
                          />
                          <div className="absolute right-5 top-full z-50 mt-1 w-40 overflow-hidden rounded-2xl bg-white py-1.5 shadow-[0_8px_30px_rgba(0,0,0,0.08)]">
                            <button
                              type="button"
                              onClick={() => openEditModal(p)}
                              className="flex w-full items-center px-4 py-2 text-left text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50"
                            >
                              Modifier
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                console.log("Suppression du produit", p.id);
                                setProduits((prev) =>
                                  prev.filter((x) => x.id !== p.id),
                                );
                                setOpenActionsId(null);
                              }}
                              className="flex w-full items-center px-4 py-2 text-left text-xs font-medium text-red-600 transition-colors hover:bg-red-50/60"
                            >
                              Supprimer
                            </button>
                          </div>
                        </>
                      )}
                    </td>
                  </tr>
                );
              })}

              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={5}
                    className="px-5 py-12 text-center text-sm text-slate-400"
                  >
                    Aucun produit trouvé.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <ProductModal
        open={isProductModalOpen}
        mode={modalMode}
        product={editingProduct}
        onClose={() => setIsProductModalOpen(false)}
        onSave={(draft, id) => handleSaveProduct(draft, id)}
      />
    </div>
  );
}


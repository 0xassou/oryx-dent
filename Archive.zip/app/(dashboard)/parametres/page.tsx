"use client";

import { useRef, useState } from "react";
import { FileImage, Image, Layers, Plus, Trash2 } from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type OngletId = "cabinet" | "preferences" | "protocoles" | "horaires" | "equipe" | "documents";

interface Consommable {
  id: string;
  nom: string;
  quantite: number;
}

interface Protocole {
  id: string;
  nom: string;
  consommables: Consommable[];
}

// ─── Données fictives ─────────────────────────────────────────────────────────

const PRODUITS_CATALOGUE = [
  "Pompe à salive",
  "Microbrush",
  "Tube Composite A2",
  "Tube Composite B1",
  "Gants nitrile (M)",
  "Masque chirurgical",
  "Carpule Articaïne 4%",
  "Coton salivaire",
  "Digue dentaire",
  "Lime endodontique NiTi",
  "Ciment de scellement",
  "Fil de rétraction",
] as const;

const INITIAL_PROTOCOLES: Protocole[] = [
  {
    id: "p1",
    nom: "Composite Simple",
    consommables: [
      { id: "c1", nom: "Pompe à salive", quantite: 1 },
      { id: "c2", nom: "Microbrush", quantite: 1 },
      { id: "c3", nom: "Tube Composite A2", quantite: 0.05 },
    ],
  },
  {
    id: "p2",
    nom: "Détartrage",
    consommables: [
      { id: "c4", nom: "Pompe à salive", quantite: 1 },
      { id: "c5", nom: "Coton salivaire", quantite: 4 },
      { id: "c6", nom: "Gants nitrile (M)", quantite: 1 },
    ],
  },
  {
    id: "p3",
    nom: "Extraction",
    consommables: [
      { id: "c7", nom: "Carpule Articaïne 4%", quantite: 2 },
      { id: "c8", nom: "Gants nitrile (M)", quantite: 2 },
      { id: "c9", nom: "Coton salivaire", quantite: 6 },
    ],
  },
  {
    id: "p4",
    nom: "Traitement Endodontique",
    consommables: [
      { id: "c10", nom: "Digue dentaire", quantite: 1 },
      { id: "c11", nom: "Lime endodontique NiTi", quantite: 3 },
      { id: "c12", nom: "Ciment de scellement", quantite: 0.1 },
      { id: "c13", nom: "Carpule Articaïne 4%", quantite: 1 },
    ],
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(16).slice(2);
}

function formatQty(q: number) {
  return Number.isInteger(q) ? String(q) : q.toFixed(2).replace(/\.?0+$/, "");
}

// ─── Sous-composant : Onglet Protocoles ───────────────────────────────────────

function ProtocolesTab() {
  const [protocoles, setProtocoles] = useState<Protocole[]>(INITIAL_PROTOCOLES);
  const [selectedId, setSelectedId] = useState<string | null>(
    INITIAL_PROTOCOLES[0].id,
  );

  // État du formulaire "Ajouter un consommable"
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProduit, setNewProduit] = useState<string>(PRODUITS_CATALOGUE[0]);
  const [newQty, setNewQty] = useState<number>(1);

  const selected = selectedId
    ? protocoles.find((p) => p.id === selectedId) ?? null
    : null;

  function addProtocole() {
    const nouveau: Protocole = {
      id: `p-${uid()}`,
      nom: `Nouveau Protocole ${protocoles.length + 1}`,
      consommables: [],
    };
    setProtocoles((prev) => [...prev, nouveau]);
    setSelectedId(nouveau.id);
  }

  function deleteSelectedProtocol() {
    if (!selectedId) return;
    setProtocoles((prev) => {
      const next = prev.filter((p) => p.id !== selectedId);
      setSelectedId(next[0]?.id ?? null);
      return next;
    });
  }

  function removeConsommable(protocoleId: string, consommableId: string) {
    setProtocoles((prev) =>
      prev.map((p) =>
        p.id === protocoleId
          ? { ...p, consommables: p.consommables.filter((c) => c.id !== consommableId) }
          : p,
      ),
    );
  }

  function addConsommable() {
    if (!selected) return;
    const newItem: Consommable = {
      id: `c-${uid()}`,
      nom: newProduit,
      quantite: newQty,
    };
    setProtocoles((prev) =>
      prev.map((p) =>
        p.id === selected.id
          ? { ...p, consommables: [...p.consommables, newItem] }
          : p,
      ),
    );
    setNewQty(1);
    setShowAddForm(false);
  }

  return (
    <div className="flex min-h-[540px] overflow-hidden rounded-3xl border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
      {/* Colonne gauche – liste des actes */}
      <aside className="flex w-64 shrink-0 flex-col bg-slate-50">
        <div className="border-b border-slate-200/60 px-4 py-4">
          <button
            type="button"
            onClick={addProtocole}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[color:var(--ds-primary)] py-2.5 text-xs font-medium text-white shadow-sm transition-colors hover:opacity-90"
          >
            <Plus className="h-4 w-4" />
            Nouveau Protocole
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto p-3">
          {protocoles.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                setSelectedId(p.id);
                setShowAddForm(false);
              }}
              className={[
                "w-full rounded-xl px-3 py-3 text-left text-sm font-medium transition-colors",
                selectedId === p.id
                  ? "bg-white text-[color:var(--ds-primary)] shadow-sm"
                  : "text-slate-600 hover:bg-white/70 hover:text-slate-800",
              ].join(" ")}
            >
              {p.nom}
              <span className="mt-0.5 block text-[11px] font-normal text-slate-400">
                {p.consommables.length} consommable
                {p.consommables.length !== 1 ? "s" : ""}
              </span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Colonne droite – constructeur */}
      <main className="flex flex-1 flex-col bg-white">
        {selected ? (
          <>
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 px-6 py-4">
              <h3 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
                {selected.nom}
              </h3>
              <button
                type="button"
                onClick={deleteSelectedProtocol}
                className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-500"
                aria-label="Supprimer le protocole"
                title="Supprimer le protocole"
              >
                <Trash2 className="h-4 w-4" />
              </button>
              <p className="mt-0.5 text-xs text-slate-500">
                Consommables utilisés par acte
              </p>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-5">
              {/* Liste des consommables */}
              <div className="space-y-2">
                {selected.consommables.length === 0 && (
                  <p className="text-sm text-slate-400">
                    Aucun consommable. Ajoutez-en un ci-dessous.
                  </p>
                )}
                {selected.consommables.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between rounded-2xl border border-slate-100 bg-slate-50/60 px-4 py-3"
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[color:var(--ds-primary-soft)] text-xs font-semibold text-[color:var(--ds-primary)]">
                        {formatQty(c.quantite)}x
                      </span>
                      <span className="text-sm font-medium text-slate-800">
                        {c.nom}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeConsommable(selected.id, c.id)}
                      className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-500"
                      aria-label={`Retirer ${c.nom}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Formulaire d'ajout */}
              {showAddForm ? (
                <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Ajouter un consommable
                  </p>
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
                    <div className="flex-1">
                      <label className="block text-xs font-medium text-slate-700">
                        Produit
                      </label>
                      <select
                        value={newProduit}
                        onChange={(e) => setNewProduit(e.target.value)}
                        className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
                      >
                        {PRODUITS_CATALOGUE.map((prod) => (
                          <option key={prod} value={prod}>
                            {prod}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="w-32">
                      <label className="block text-xs font-medium text-slate-700">
                        Quantité
                      </label>
                      <div className="mt-1.5 flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() =>
                            setNewQty((q) => Math.max(0.05, parseFloat((q - 0.05).toFixed(2))))
                          }
                          className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-sm font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                          −
                        </button>
                        <input
                          type="number"
                          min={0.05}
                          step={0.05}
                          value={newQty}
                          onChange={(e) =>
                            setNewQty(parseFloat(e.target.value) || 0.05)
                          }
                          className="w-14 rounded-xl border border-slate-200 bg-white px-2 py-2 text-center text-sm text-slate-800 outline-none focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setNewQty((q) => parseFloat((q + 0.05).toFixed(2)))
                          }
                          className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-sm font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={addConsommable}
                      className="rounded-xl bg-[color:var(--ds-primary)] px-4 py-2 text-xs font-medium text-white shadow-sm transition-colors hover:opacity-90"
                    >
                      Valider
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-medium text-slate-600 transition-colors hover:bg-slate-50"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowAddForm(true)}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-200 py-3 text-sm font-medium text-slate-500 transition-colors hover:border-[color:var(--ds-primary)]/50 hover:text-[color:var(--ds-primary)]"
                >
                  <Plus className="h-4 w-4" />
                  Ajouter un consommable
                </button>
              )}
            </div>
          </>
        ) : (
          <div className="flex flex-1 items-center justify-center">
            <p className="text-sm text-slate-400">
              Sélectionnez un protocole à gauche.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

// ─── Sous-composant : Onglet Horaires ─────────────────────────────────────────

function HorairesTab() {
  const jours = [
    "Lundi",
    "Mardi",
    "Mercredi",
    "Jeudi",
    "Vendredi",
    "Samedi",
    "Dimanche",
  ] as const;

  type JourKey = (typeof jours)[number];
  type Horaire = { ouvert: boolean; debut: string; fin: string };

  const initial = jours.reduce<Record<JourKey, Horaire>>((acc, j) => {
    const isWeekday = !["Samedi", "Dimanche"].includes(j);
    acc[j] = { ouvert: isWeekday, debut: "09:00", fin: "18:00" };
    return acc;
  }, {} as Record<JourKey, Horaire>);

  const [horaires, setHoraires] = useState<Record<JourKey, Horaire>>(initial);

  function toggleJour(jour: JourKey) {
    setHoraires((prev) => ({
      ...prev,
      [jour]: { ...prev[jour], ouvert: !prev[jour].ouvert },
    }));
  }

  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm">
      <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
        Horaires
      </h2>
      <p className="mt-1 text-xs text-slate-500">
        Paramétrez les heures d&apos;ouverture et de fermeture.
      </p>

      <div className="mt-6 overflow-hidden rounded-2xl border border-slate-100">
        {jours.map((jour) => {
          const h = horaires[jour];
          return (
            <div
              key={jour}
              className="flex items-center gap-4 border-b border-slate-100 p-4 last:border-b-0"
            >
              <div className="w-32 shrink-0 text-sm font-medium text-slate-700">
                {jour}
              </div>

              <button
                type="button"
                onClick={() => toggleJour(jour)}
                aria-pressed={h.ouvert}
                className={[
                  "rounded-xl border px-3 py-2 text-xs font-medium transition-colors",
                  h.ouvert
                    ? "border-[color:var(--ds-primary)]/30 bg-[color:var(--ds-primary)]/10 text-[color:var(--ds-primary)]"
                    : "border-slate-200 bg-slate-50 text-slate-500",
                ].join(" ")}
              >
                {h.ouvert ? "Ouvert" : "Fermé"}
              </button>

              <div className="flex flex-1 items-center gap-3">
                <div className="w-40">
                  <label className="block text-[11px] font-medium text-slate-500">
                    Heure d&apos;ouverture
                  </label>
                  <input
                    type="time"
                    value={h.debut}
                    disabled={!h.ouvert}
                    onChange={(e) =>
                      setHoraires((prev) => ({
                        ...prev,
                        [jour]: { ...prev[jour], debut: e.target.value },
                      }))
                    }
                    className={[
                      "mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 outline-none transition-colors",
                      "focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20",
                      !h.ouvert ? "cursor-not-allowed opacity-50" : "",
                    ].join(" ")}
                  />
                </div>

                <div className="w-40">
                  <label className="block text-[11px] font-medium text-slate-500">
                    Heure de fermeture
                  </label>
                  <input
                    type="time"
                    value={h.fin}
                    disabled={!h.ouvert}
                    onChange={(e) =>
                      setHoraires((prev) => ({
                        ...prev,
                        [jour]: { ...prev[jour], fin: e.target.value },
                      }))
                    }
                    className={[
                      "mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 outline-none transition-colors",
                      "focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20",
                      !h.ouvert ? "cursor-not-allowed opacity-50" : "",
                    ].join(" ")}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Sous-composant : Onglet Équipe ──────────────────────────────────────────

function EquipeTab() {
  type Role = "Dentiste" | "Assistante" | "Secrétaire";

  const [membres, setMembres] = useState<
    { id: string; nom: string; role: Role }[]
  >([
    { id: "m1", nom: "Dr. Assil Messaoudi (Admin/Dentiste)", role: "Dentiste" },
    { id: "m2", nom: "Sarah (Secrétaire)", role: "Secrétaire" },
  ]);

  function inviteMember() {
    console.log("Inviter un membre");
  }

  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
            Équipe
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Gestion des membres du cabinet.
          </p>
        </div>

        <button
          type="button"
          onClick={inviteMember}
          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 hover:border-slate-300"
        >
          <Plus className="h-4 w-4 text-[color:var(--ds-primary)]" />
          + Inviter un membre
        </button>
      </div>

      <div className="mt-6 overflow-hidden rounded-2xl border border-slate-100">
        <div className="grid grid-cols-1 gap-0">
          {membres.map((m) => (
            <div
              key={m.id}
              className="grid grid-cols-1 gap-3 px-4 py-4 sm:grid-cols-[1fr_220px]"
            >
              <div className="text-sm font-medium text-slate-800">{m.nom}</div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500">
                  Rôle
                </label>
                <select
                  value={m.role}
                  onChange={(e) => {
                    const nextRole = e.target.value as Role;
                    setMembres((prev) =>
                      prev.map((x) =>
                        x.id === m.id ? { ...x, role: nextRole } : x,
                      ),
                    );
                  }}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
                >
                  <option value="Dentiste">Dentiste</option>
                  <option value="Assistante">Assistante</option>
                  <option value="Secrétaire">Secrétaire</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Sous-composant : Onglet Documents (Premium) ────────────────────────────

function DocumentsTab() {
  const [logoName, setLogoName] = useState<string | null>(null);
  const [backgroundName, setBackgroundName] = useState<string | null>(null);
  const [footer, setFooter] = useState(
    "N° d’immatriculation : 123456789\nAdresse du cabinet : 12 rue des Lilas, 75011 Paris",
  );
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const backgroundInputRef = useRef<HTMLInputElement | null>(null);

  function handleFiles(files: FileList | null | undefined) {
    const file = files?.[0];
    if (!file) return;
    setLogoName(file.name);
  }

  function handleBackgroundFiles(files: FileList | null | undefined) {
    const file = files?.[0];
    if (!file) return;
    setBackgroundName(file.name);
    console.log("Upload background", file.name, file.type, file.size);
  }

  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
            Documents (Premium)
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Personnalisez le header et le pied de page de vos documents.
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl bg-white p-4 shadow-sm">
          <p className="text-sm font-semibold text-slate-700">Logo d&apos;en-tête</p>

          <div
            className="mt-3 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-slate-200 bg-slate-50/70 p-8 text-center transition-colors hover:border-[color:var(--ds-primary)]/40"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleFiles(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            role="button"
            tabIndex={0}
            aria-label="Uploader un logo"
          >
            <Image className="h-5 w-5 text-slate-400" />
            <p className="text-xs font-medium text-slate-600">
              Glisser-déposer un logo d&apos;en-tête
            </p>
            <p className="text-[11px] text-slate-500">
              (PNG/JPG, maquette)
            </p>
            {logoName && (
              <p className="mt-2 text-[11px] font-medium text-[color:var(--ds-primary)]">
                {logoName}
              </p>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
        </div>

        <div className="rounded-3xl bg-white p-4 shadow-sm">
          <label className="block text-sm font-semibold text-slate-700">
            Pied de page par défaut
          </label>
          <textarea
            value={footer}
            onChange={(e) => setFooter(e.target.value)}
            rows={6}
            className="mt-3 w-full resize-y rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20"
          />
        </div>
      </div>

        <div className="mt-6 rounded-3xl bg-white p-4 shadow-sm">
          <div className="px-1">
            <h3 className="text-sm font-semibold text-slate-700">
              Arrière-plan complet / Filigrane (A4)
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Uploadez le design complet de votre papier à en-tête. Le texte
              de vos ordonnances s&apos;imprimera par-dessus.
            </p>
          </div>

          <div
            className="mt-4 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-slate-200 bg-slate-50/70 p-10 text-center transition-colors hover:border-[color:var(--ds-primary)]/40"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleBackgroundFiles(e.dataTransfer.files);
            }}
            onClick={() => backgroundInputRef.current?.click()}
            role="button"
            tabIndex={0}
            aria-label="Uploader l'arrière-plan A4"
          >
            <Layers className="h-5 w-5 text-slate-400" />
            <p className="text-xs font-medium text-slate-600">
              Glisser-déposer l&apos;arrière-plan (ou cliquez)
            </p>
            <p className="text-[11px] text-slate-500">
              Format A4 recommandé (PDF, PNG, JPG)
            </p>
            {backgroundName && (
              <p className="text-[11px] font-medium text-[color:var(--ds-primary)]">
                {backgroundName}
              </p>
            )}
          </div>

          <input
            ref={backgroundInputRef}
            type="file"
            accept=".pdf,image/png,image/jpeg,image/jpg"
            className="hidden"
            onChange={(e) => handleBackgroundFiles(e.target.files)}
          />
        </div>

      <div className="mt-6 flex justify-end">
        <button
          type="button"
          className="rounded-2xl bg-[color:var(--ds-primary)] px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:opacity-90"
        >
          Sauvegarder
        </button>
      </div>
    </div>
  );
}

// ─── Page principale Paramètres ───────────────────────────────────────────────

const ONGLETS: { id: OngletId; label: string }[] = [
  { id: "cabinet", label: "Cabinet" },
  { id: "preferences", label: "Préférences" },
  { id: "protocoles", label: "Protocoles de Soins" },
  { id: "horaires", label: "Horaires" },
  { id: "equipe", label: "Équipe" },
  { id: "documents", label: "Documents" },
];

const inputBase =
  "mt-1.5 w-full max-w-md rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition-colors focus:border-[color:var(--ds-primary)] focus:ring-2 focus:ring-[color:var(--ds-primary)]/20";

export default function ParametresPage() {
  const [onglet, setOnglet] = useState<OngletId>("cabinet");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-[color:var(--ds-text)]">
          Paramètres
        </h1>
        <p className="mt-1 text-xs text-slate-500">
          Configuration du cabinet et des protocoles
        </p>
      </div>

      {/* Onglets */}
      <div className="flex items-center gap-1 rounded-2xl border border-slate-200/60 bg-white p-1 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
        {ONGLETS.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => setOnglet(o.id)}
            className={[
              "rounded-xl px-4 py-2 text-sm font-medium transition-all",
              onglet === o.id
                ? "bg-[color:var(--ds-primary)] text-white shadow-sm"
                : "text-slate-500 hover:text-slate-700",
            ].join(" ")}
          >
            {o.label}
          </button>
        ))}
      </div>

      {/* Contenu */}
      {onglet === "cabinet" && (
        <div className="rounded-3xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
          <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
            Informations du Cabinet
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Informations générales de votre cabinet dentaire.
          </p>

          <div className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="nom-cabinet"
                className="block text-sm font-medium text-slate-700"
              >
                Nom du cabinet
              </label>
              <input
                id="nom-cabinet"
                type="text"
                defaultValue="Cabinet Dr. Assil"
                className={inputBase}
              />
            </div>
            <div>
              <label
                htmlFor="adresse"
                className="block text-sm font-medium text-slate-700"
              >
                Adresse
              </label>
              <input
                id="adresse"
                type="text"
                defaultValue="12 rue des Lilas, 75001 Paris"
                className={inputBase}
              />
            </div>
            <div>
              <label
                htmlFor="telephone"
                className="block text-sm font-medium text-slate-700"
              >
                Téléphone
              </label>
              <input
                id="telephone"
                type="tel"
                defaultValue="01 23 45 67 89"
                className={inputBase}
              />
            </div>
          </div>

          <div className="mt-6">
            <button
              type="button"
              className="rounded-2xl bg-[color:var(--ds-primary)] px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:opacity-90"
            >
              Sauvegarder
            </button>
          </div>
        </div>
      )}

      {onglet === "preferences" && (
        <div className="rounded-3xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
          <h2 className="text-base font-semibold tracking-tight text-[color:var(--ds-text)]">
            Préférences
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Personnalisez l'application selon vos besoins.
          </p>

          <div className="mt-6">
            <label
              htmlFor="langue"
              className="block text-sm font-medium text-slate-700"
            >
              Langue
            </label>
            <select
              id="langue"
              defaultValue="fr"
              className={inputBase}
            >
              <option value="fr">Français</option>
              <option value="en">English</option>
              <option value="ar">العربية</option>
            </select>
          </div>

          <div className="mt-6">
            <button
              type="button"
              className="rounded-2xl bg-[color:var(--ds-primary)] px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:opacity-90"
            >
              Sauvegarder
            </button>
          </div>
        </div>
      )}

      {onglet === "protocoles" && <ProtocolesTab />}
      {onglet === "horaires" && <HorairesTab />}
      {onglet === "equipe" && <EquipeTab />}
      {onglet === "documents" && <DocumentsTab />}
    </div>
  );
}
